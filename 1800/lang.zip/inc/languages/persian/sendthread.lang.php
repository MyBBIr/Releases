<?php 
/**
 * MyBB 1.8 Persian Language Pack
 * Copyright 2014 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */

$l['nav_sendthread'] = "ارسال موضوع به یک دوست";
$l['send_thread'] = "ارسال به دوست";
$l['recipient'] = "گیرنده:";
$l['recipient_note'] = "آدرس رایانامه دوستان خود را اینجا وارد نمایید.";
$l['subject'] = "موضوع:";
$l['message'] = "متن:";
$l['image_verification'] = "تصویر امنیتی";
$l['verification_subnote'] = "(غیرحساس به بزرگی و کوچکی حروف)";
$l['verification_note'] = "لطفا متن داخل تصویر را عیناً وارد نمائید. این کار برای جلوگیری از فرایند‌های خودکار صورت می‌گیرد.";
$l['error_nosubject'] = "شما می‌بایست برای ارسال موضوع، یک عنوان انتخاب نمایید";
$l['error_nomessage'] = "شما می‌بایست برای ارسال موضوع، یک متن وارد نمایید";