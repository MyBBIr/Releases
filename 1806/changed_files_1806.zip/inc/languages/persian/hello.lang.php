<?php
/**
 * MyBB 1.8 Persian Language Pack
 * Copyright 2014 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */

$l['hello'] = 'سلام جهان!';
$l['hello_add'] = 'افزودن';
$l['hello_add_message'] = 'افزودن پیام';
$l['hello_empty'] = 'هیچ پیامی یافت نشد.';
$l['hello_message_empty'] = 'پیام نمی‌تواند خالی باشد.';
$l['hello_done'] = 'یک پیام جدید با موفقیت افزوده‌شد.';