<?php 
/**
 * MyBB 1.8 Persian Language Pack
 * Copyright 2014 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */

/* Help Section 1 */
$l['s1_name'] = "تعمیر و نگهداری کاربر";
$l['s1_desc'] = "دستورالعمل کاری برای نگهداری حساب کاربری در انجمن.";
/* Help Section 2 */
$l['s2_name'] = "ارسال کردن";
$l['s2_desc'] = "ارسال‌کردن یا پاسخ دادن به موضوع و استفاده معمولی از انجمن";
