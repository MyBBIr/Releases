<?php
/**
 * MyBB 1.8 Persian Language Pack
 * Copyright 2014 My-BB.Ir Group & iora.ir, All Rights Reserved
 *
 * Translate By: iora.ir & My-BB.Ir
 */

$l['nav_helpdocs'] = "مستندات راهنما";
$l['nav_smilies'] = "لیست شکلک‌ها";
$l['nav_syndication'] = "خوراک (آراِس‌اِس) آخرین موضوعات";
$l['buddy_list'] = "لیست دوستان";
$l['online_none'] = "<em>شما هیچ دوستی ندارید که آنلاین باشد.</em>";
$l['online'] = "آنلاین";
$l['offline_none'] = "<em>شما هیچ دوستی ندارید که آفلاین باشد.</em>";
$l['offline'] = "آفلاین";
$l['delete_buddy'] = "X";
$l['pm_buddy'] = "ارسال پیام‌خصوصی";
$l['last_active'] = "<strong>آخرین فعالیت:</strong> {1}";
$l['close'] = "بستن";
$l['no_buddies'] = "<em>لیست دوستان شما خالی است. جهت اضافه کردن اعضا به لیست دوستان، وارد کنترل پنل کاربری خود و یا پروفایل آنها بشوید..</em>";
$l['help_docs'] = "مستندات راهنما";
$l['search_help_documents'] = "جستجو در مستندات راهنما";
$l['search_by_name'] = "جستجو براساس نام";
$l['search_by_document'] = "جستجو براساس سند";
$l['enter_keywords'] = "کلمات‌کلیدی را واردکنید";
$l['search'] = "جستجو";
$l['redirect_searchresults'] = "با‌سپاس، جستجوی شما ثبت‌شد، هم‌اکنون به صفحه‌ی نتایج خواهید رفت.";
$l['search_results'] = "نتایج جستجو";
$l['help_doc_results'] = "نتایج مستندات راهنما";
$l['document'] = "سند";
$l['error_nosearchresults'] = "متاسفیم، ولی با معیار‌های خواسته شده موردی یافت نشد، لطفا بازگردید و معیارهای جستجوتان را تغییر دهید.";
$l['no_help_results'] = "متاسفیم، اما با معیارهای خواسته شده موردی یافت نشد.";
$l['error_helpsearchdisabled'] = "امکان جستجو در مستندات راهنما توسط مدیریت بسته شده‌است.";
$l['smilies_listing'] = "لیست شکلک‌ها";
$l['name'] = "نام";
$l['abbreviation'] = "مخفف";
$l['click_to_add'] = "بر روی یکی از شکلک‌ها کلیک کنید تا در متن پیام شما قرار گیرد.";
$l['close_window'] = "بستن پنجره";
$l['no_smilies'] = "هم‌اکنون هیچ شکلکی موجود نمی‌باشد.";
$l['who_posted'] = "چه کسی مطلب ارسال کرده است؟";
$l['total_posts'] = "مجموع ارسالها:";
$l['user'] = "کاربر";
$l['num_posts'] = "# ارسال";
$l['forum_rules'] = "{1} - قوانین";
$l['error_invalid_limit'] = "محدوده وارد شده برای نمایش آراِس‌اِس معتبر نمی‌باشد. لطفا یک محدوده معتبر را وارد نمایید.";
$l['syndication'] = "آراِس‌اِس آخرین موضوعات";
$l['syndication_generated_url'] = "آدرس آراِس‌اِس ایجاد شده برای شما:";
$l['syndication_note'] = "در زیر شما می‌توانید لینک آراِس‌اِس ایجاد کنید. لینک‌ها می‌توانند برای هر تعداد از انجمن‌ها ایجاد شوند. سپس شما یک لینک آراِس‌اِس برای درج در آراِس‌اِس خوان خود دارید. <i><a href=\"https://fa.wikipedia.org/wiki/RSS\" target=\"_blank\">آراِس‌اِس چیست؟</a></i>";
$l['syndication_forum'] = "انجمن برای تهیه آراِس‌اِس:";
$l['syndication_forum_desc'] = "لطفاً انجمنی را از لیست انتخاب نمایید. از کلید CTRL برای انتخاب همزمان چند انجمن استفاده نمایید.";
$l['syndication_version'] = "نسخه خوراک آراِس‌اِس:";
$l['syndication_version_desc'] = "لطفاً نسخه آراِس‌اِس ای را که قصد تولید آن را دارید مشخص نمایید.";
$l['syndication_version_json1'] = "JSON Feed 1";
$l['syndication_version_atom1'] = "Atom ۱.۰";
$l['syndication_version_rss2'] = "آراِس‌اِس ۲.۰۰ (پیش‌فرض)";
$l['syndication_generate'] = "تولید لینک آراِس‌اِس";
$l['syndication_limit'] = "محدودیت:";
$l['syndication_limit_desc'] = "تعداد موضوعات دانلود شده بصورت همزمان. ۵۰ حداکثر مقدار است.";
$l['syndication_threads_time'] = "موضوعات هم زمان";
$l['syndicate_all_forums'] = "آراِس‌اِس تمام انجمن‌ها";
$l['redirect_markforumread'] = "انجمن انتخاب شده به عنوان خوانده شده علامت گذاری شد.";
$l['redirect_markforumsread'] = "تمام انجمن‌ها به عنوان خوانده شده علامت گذاری شدند.";
$l['redirect_forumpasscleared'] = "رمز ذخیره شده برای این انجمن پاک شد.";
$l['redirect_cookiescleared'] = "تمام کوکی‌ها پاک شدند.";
$l['error_invalidforum'] = "انجمن نامعتبر";
$l['error_invalidhelpdoc'] = "سند راهنمای مشخص شده وجود ندارد.";
$l['error_invalidsearch'] = "جستجوی نامعتبری انتخاب شده‌است. لطفا برگردید و دوباره تلاش کنید.";
$l['error_no_search_support'] = "این موتور پایگاه‌داده، جستجوکردن را پشتیبانی نمی‌کند.";
$l['error_searchflooding'] = "متاسفیم، اما شما فقط می‌توانید در هر {1} ثانیه یکبار جستجو کنید. لطفا {2} ثانیه‌ی دیگر قبل از تلاش برای جستجوی دوباره صبر کنید.";
$l['error_searchflooding_1'] = "متاسفیم، اما شما فقط می‌توانید در هر {1} ثانیه یکبار جستجو کنید. لطفا یک ثانیه‌ی دیگر قبل از تلاش برای جستجوی دوباره صبر کنید.";
$l['error_minsearchlength'] = "یک یا چند واژه مورد جستجوی شما کوتاه‌تر از حداقل طول هستند. حداقل طول واژه جستجو {1} کاراکتر است.<br /><br />اگر می‌خواهید یک عبارت کامل را جستجو کنید، آن را داخل گیومه قرار دهید. برای نمونه \"The quick brown fox jumps over the lazy dog\".";
$l['dst_settings_updated'] = "تنظیم ذخیره سازی نور روز بطور خودکار انجام شد.<br /><br />اکنون به صفحه اول انجمن انتقال داده خواهید شد.";
