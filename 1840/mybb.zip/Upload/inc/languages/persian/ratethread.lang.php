<?php
/**
 * MyBB 1.8 Persian Language Pack
 * Copyright 2014 My-BB.Ir Group & iora.ir, All Rights Reserved
 *
 * Translate By: iora.ir & My-BB.Ir
 */

$l['redirect_threadrated'] = "متشکریم, موضوع با موفقیت رای دهی شد. شما اکنون به موضوع باز خواهید گشت.";
$l['thread_doesnt_exist'] = "نمی‌توانید به موضوعی که وجود ندارد امتیاز بدهید.";
$l['error_invalidrating'] = "شما یک رای نامعتبر را برای موضوع انتخاب نموده اید. لطفاً به قبل باز گردید و مجدداً تلاش کنید.";
$l['error_alreadyratedthread'] = "متاسفیم, شما قبلاً به این موضوع رای داده اید.";
$l['error_cannotrateownthread'] = "متاسفیم، شما نمی‌توانید به موضوع خودتان رای دهید.";

$l['rating_votes_average'] = "{1} رای - {2} از میانگین 5 رای";
$l['one_star'] = "1 ستاره از 5 ستاره";
$l['two_stars'] = "2 ستاره از 5 ستاره";
$l['three_stars'] = "3 ستاره از 5 ستاره";
$l['four_stars'] = "4 ستاره از 5 ستاره";
$l['five_stars'] = "5 ستاره از 5 ستاره";
$l['rating_added'] = "رای شما اضافه گردید!";
