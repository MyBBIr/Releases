<?php
/**
 * MyBB 1.8 Persian Language Pack
 * Copyright 2014 My-BB.Ir Group & iora.ir, All Rights Reserved
 *
 * Translate By: iora.ir & My-BB.Ir
 */

$l['nav_showteam'] = "تیم مدیریتی انجمن";
$l['forum_team'] = "تیم مدیریتی انجمن";
$l['moderators'] = "مدیر‌ها";
$l['username'] = "نام‌کاربری";
$l['lastvisit'] = "آخرین بازدید";
$l['email'] = "رایانامه";
$l['pm'] = "پیام‌خصوصی";
$l['mod_forums'] = "انجمن‌(ها)";
$l['mod_groups'] = "گروه‌(ها)";
$l['online'] = "آنلاین";
$l['offline'] = "آفلاین";
$l['away'] = "غایب";

$l['group_leaders'] = "رهبران گروه";
$l['group_members'] = "کاربر(ها)";
$l['no_members'] = "کاربری در این گروه کاربری وجود ندارد.";
$l['showteam_disabled'] = "نمایش تیم انجمن توسط مدیر غیرفعال شده است.";
$l['error_noteamstoshow'] = "تیمی‌برای نشان دادن وجود ندارد.";
