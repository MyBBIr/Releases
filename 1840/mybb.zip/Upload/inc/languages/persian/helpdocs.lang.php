<?php
/**
 * MyBB 1.8 Persian Language Pack
 * Copyright 2014 My-BB.Ir Group & iora.ir, All Rights Reserved
 *
 * Translate By: iora.ir & My-BB.Ir
 */

/* Uncomment the lines below to use these language strings rather than the help documents set in the database */


/* Help Document 1 */
$l['d1_name'] = "عضویت کاربر";
$l['d1_desc'] = "مزایای عضویت در این انجمن.";
$l['d1_document'] = "برای استفاده از بعضی از بخش‌های این انجمن نیاز است که در انجمن عضو شوید. عضویت برای همه افراد آزاد می‌باشد و این عمل چند دقیقه بیشتر طول نمی‌کشد.
<br><br>زمانی که شما در انجمن عضو می‌شوید می‌توانید برای سایر اعضا پیام بفرستید یا موضوع و مشکل خود را ارسال نمایید. ضمنا می‌توانید پروفایل ویژه خود را نیز داشته باشید.
<br><br>برخی از مزایای عضویت در انجمن عبارتند از:<br> اشتراک در موضوع‌ها, علاقمندی‌ها, تغییر قالب انجمن, دستیابی به ویرایشگر مخصوص خود و ارسال رایانامه برای اعضا.";
/* Help Document 2 */
$l['d2_name'] = "بروز رسانی پروفایل";
$l['d2_desc'] = "تغییر اطلاعات جاری مربوط به شما.";
$l['d2_document'] = "بعضی مواقع ممکن است که شما بخواهید اطلاعات پروفایل خود را بروز رسانی نمایید؛ اطلاعاتی مانند: اطلاعات مربوط به مسنجر، رمز ورود، یا تغییر آدرس رایانامه.<br>شما می‌توانید تمام اطلاعات کاربری خود را از طریق کنترل پنل ویژه خود در انجمن تغییر دهید. برای دسترسی به کنترل پنل، تنها کافی است که بر روی عنوان کنترل پنل کاربر در گوشه بالای سمت چپ صفحه کلیک نمایید. از آنجا \"ویرایش مشخصات\" را انتخاب کرده و موارد مد نظر خود را تغییر دهید، سپس موافقت خود را با انجام تغییرات اعلام نمایید تا تغییرات جدید برای شما اجرا شود.";
/* Help Document 3 */
$l['d3_name'] = "استفاده از کوکی‌ها در مای‌بی‌بی";
$l['d3_desc'] = "این انجمن از کوکی‌ها برای ثبت اطلاعات عضویت و ورود و خروج شما استفاده می‌کند.";
$l['d3_document'] = "در صورتی که شما در سایت عضو شده باشید اطلاعات مربوط به عضویت و ورود و خروج شما از طریق کوکی‌ها انجام می‌شود، ضمنا اطلاعات مربوط به آخرین بازدید شما از انجمن هم از طریق کوکی‌ها ثبت می‌شود.
<br><br>کوکی‌ها اسناد متنی کوچکی هستند که در کامپیوتر شما ذخیره می‌شوند; استفاده از کوکی‌ها فقط برای موارد امنیتی می‌باشد و استفاده دیگری از آنها نمی‌شود.
<br><br>کوکی‌ها ضمنا اطلاعات مربوط به موضوع‌های خوانده شده توسط شما را نیز ثبت می‌نماید.
<br><br>برای حذف تمام کوکی‌های ذخیره شده توسط این انجمن می‌توانید <a href=\"misc.php?action=clearcookies&amp;my_post_key={1}\">اینجا</a>کلیک نمایید.";
/* Help Document 4 */
$l['d4_name'] = "ورود و خروج";
$l['d4_desc'] = "روش ورود و خروج از انجمن.";
$l['d4_document'] = "وقتی شما برای یک بار وارد این انجمن می‌شوید کوکی‌ها فعال می‌شوند واطلاعات ورود شما را ثبت می‌کنند و برای بار بعدی نیازی به وارد کردن رمز ورود و نام‌کاربری نمی‌باشد و شما به صورت خودکار وارد انجمن خواهید شد. با استفاده از کوکی‌ها غیر از شما هیچ کس دیگری نمی‌تواند وارد اشتراک کاربری شما در این انجمن شود.<br> درصورتی کوکی‌ها برای شما هنگام بازدید اجرا نمی‌شوند که بعد از ورود به انجمن از حساب کاربری خود خارج شوید.
<br><br>برای ورود فقط کافی است که بر روی گزینه ورود در بالا انجمن کلیک نمایید. برای خروج نیز بر روی گزینه خروج در همان منوی بالای صفحه کلیک نمایید. در صورتی که عملیات خروج انجام نشد کوکی‌ها را از روی سیستم خود پاک کنید.";
/* Help Document 5 */
$l['d5_name'] = "ارسال یک موضوع جدید";
$l['d5_desc'] = "شروع یک موضوع جدید در انجمن.";
$l['d5_document'] = "در صورتی که شما قبلا در انجمن عضو شده اید و می‌خواهید یک موضوع جدید را ارسال نمایید، بسیار ساده است.فقط کافی است که در انجمن مورد نظر خود بر روی دکمه \"موضوع جدید\" کلیک نمایید. لزوما شما دسترسی به تمام انجمنها برای ارسال مطلب یا جواب ندارید. ممکن است که بعضی از انجمنها برای مدیران باشد و یا اینکه مدیریت کل انجمن آن را برای اعضای عادی قفل کرده باشد و فقط قابل مشاهده باشد.";
/* Help Document 6 */
$l['d6_name'] = "ارسال یک پاسخ";
$l['d6_desc'] = "پاسخ به موضوع‌ها در انجمن.";
$l['d6_document'] = "ممکن است که شما علاقمند به دادن پاسخ به یک موضوع در انجمنها باشید.برای اینکار می‌توانید بر روی دکمه. \"ارسال پاسخ\" در همان موضوع کلیک کرده و جواب خود را ارسال نمایید. ضمنا می‌توانید از قسمت پایین هر انجمن از کادر ارسال پاسخ سریع نیز استفاده نمایید.
<br><br>در صورتی که برخی از جواب‌ها نامناسب باشد مدیران انجمن این اجازه را دارند که ارسال‌های شما را ویرایش یا حذف نمایند.";
/* Help Document 7 */
$l['d7_name'] = "مای‌کد";
$l['d7_desc'] = "آشنایی با امکانات مای‌کد برای بهتر شدن ارسال‌های شما.";
$l['d7_document'] = "شما می‌توانید از MyCode، که با نام BBCode نیز شناخته می‌شود، برای افزودن جلوه یا قالب‌بندی به ارسال‌های خود استفاده کنید. MyCode نسخه‌ای ساده‌شده از HTML است و با ساختاری مشابه تگ‌های HTML که شاید از قبل با آن آشنا باشید به کار می‌رود.
<br /><br />جدول زیر یک راهنمای سریع برای MyCodeهای موجود است:
<br /><br />
<table class=\"tborder\" cellspacing=\"0\" cellpadding=\"5\" border=\"0\" style=\"width:90%\">
<tbody>
<tr>
<td class=\"tcat\" style=\"width:55%\"><span class=\"smalltext\"><strong>ورودی</strong></span></td>
<td class=\"tcat\" style=\"width:35%\"><span class=\"smalltext\"><strong>خروجی</strong></span></td>
<td class=\"tcat\" style=\"width:10%\"><span class=\"smalltext\"><strong>توضیحات</strong></span></td>
</tr>
<tr>
<td class=\"trow1\">[b]This text is bold[/b]</td>
<td class=\"trow1\"><span class=\"mycode_b\">This text is bold</span></td>
<td class=\"trow1\"></td>
</tr>
<tr>
<td class=\"trow2\">[i]This text is italicized[/i]</td>
<td class=\"trow2\"><span class=\"mycode_i\">This text is italicized</span></td>
<td class=\"trow2\"></td>
</tr>
<tr>
<td class=\"trow1\">[u]This text is underlined[/u]</td>
<td class=\"trow1\"><span class=\"mycode_u\">This text is underlined</span></td>
<td class=\"trow1\"></td>
</tr>
<tr>
<td class=\"trow2\">[s]This text is struck out[/s]</td>
<td class=\"trow2\"><span class=\"mycode_s\">This text is struck out</span></td>
<td class=\"trow2\"></td>
</tr>
<tr>
<td class=\"trow1\">[url]http://www.example.com/[/url]</td>
<td class=\"trow1\"><a href=\"http://www.example.com/\" class=\"mycode_url\" rel=\"nofollow\">http://www.example.com/</a></td>
<td class=\"trow1\">اگر آدرس، پروتکل درست داشته باشد خودکار پیوند می‌شود.</td>
</tr>
<tr>
<td class=\"trow2\">[url=http://www.example.com/]Example.com[/url]</td>
<td class=\"trow2\"><a href=\"http://www.example.com/\" class=\"mycode_url\" rel=\"nofollow\">Example.com</a></td>
<td class=\"trow2\"></td>
</tr>
<tr>
<td class=\"trow1\">[email]example@example.com[/email]</td>
<td class=\"trow1\"><a href=\"mailto:example@example.com\" class=\"mycode_email\">example@example.com</a></td>
<td class=\"trow1\"></td>
</tr>
<tr>
<td class=\"trow2\">[email=example@example.com]E-mail Me![/email]</td>
<td class=\"trow2\"><a href=\"mailto:example@example.com\" class=\"mycode_email\">E-mail Me!</a></td>
<td class=\"trow2\">برای افزودن موضوع، بعد از نشانی رایانامه از <strong>?subject=موضوع</strong> استفاده کنید.</td>
</tr>
<tr>
<td class=\"trow1\">[quote]Quoted text will be here[/quote]</td>
<td class=\"trow1\"><blockquote class=\"mycode_quote\"><cite>Quote:</cite>Quoted text will be here</blockquote></td>
<td class=\"trow1\"></td>
</tr>
<tr>
<td class=\"trow2\">[code]Text with preserved formatting[/code]</td>
<td class=\"trow2\"><div class=\"codeblock\"><div class=\"title\">Code:</div><div class=\"body\" dir=\"ltr\"><code>Text with preserved formatting</code></div></div></td>
<td class=\"trow2\"></td>
</tr>
<tr>
<td class=\"trow1\">[php]&lt;?php echo \"Hello world!\";?&gt;[/php]</td>
<td class=\"trow1\"><div class=\"codeblock phpcodeblock\"><div class=\"title\">PHP Code:</div><div class=\"body\"><div dir=\"ltr\"><code><span style=\"color: #0000BB\">&lt;?php&nbsp;</span><span style=\"color: #007700\">echo&nbsp;</span><span style=\"color: #DD0000\">\"Hello&nbsp;world!\"</span><span style=\"color: #007700\">;</span><span style=\"color: #0000BB\">?&gt;</span></code></div></div></div></td>
<td class=\"trow1\"></td>
</tr>
<tr>
<td class=\"trow2\">[img]https://secure.php.net/images/php.gif[/img]</td>
<td class=\"trow2\"><img src=\"https://secure.php.net/images/php.gif\" class=\"mycode_img\"></td>
<td class=\"trow2\"></td>
</tr>
<tr>
<td class=\"trow1\">[img=50x50]https://secure.php.net/images/php.gif[/img]</td>
<td class=\"trow1\"><img src=\"https://secure.php.net/images/php.gif\" width=\"50\" height=\"50\" class=\"mycode_img\"></td>
<td class=\"trow1\"></td>
</tr>
<tr>
<td class=\"trow2\">[color=red]This text is red[/color]</td>
<td class=\"trow2\"><span style=\"color: red;\">This text is red</span></td>
<td class=\"trow2\"></td>
</tr>
<tr>
<td class=\"trow1\">[size=3]This text is size 3[/size]</td>
<td class=\"trow1\"><span style=\"font-size: 3;\">This text is size 3</span></td>
<td class=\"trow1\"></td>
</tr>
<tr>
<td class=\"trow2\">[font=Tahoma]This font is Tahoma[/font]</td>
<td class=\"trow2\"><span style=\"font-family: Tahoma;\">This font is Tahoma</span></td>
<td class=\"trow2\"></td>
</tr>
<tr>
<td class=\"trow1\">[align=center]This is centered[/align]</td>
<td class=\"trow1\"><div align=\"center\">This is centered</div></td>
<td class=\"trow1\"></td>
</tr>
<tr>
<td class=\"trow2\">[align=right]This is right-aligned[/align]</td>
<td class=\"trow2\"><div align=\"right\">This is right-aligned</div></td>
<td class=\"trow2\"></td>
</tr>
<tr>
<td class=\"trow1\">[list]<br />[*]List Item #1<br />[*]List Item #2<br />[*]List Item #3<br />[/list]</td>
<td class=\"trow1\"><ul><li>List item #1</li><li>List item #2</li><li>List item #3</li></ul></td>
<td class=\"trow1\">برای فهرست شماره‌دار از <strong>[list=1]</strong> و برای فهرست الفبایی از <strong>[list=a]</strong> استفاده کنید.</td>
</tr>
</tbody>
</table>";
