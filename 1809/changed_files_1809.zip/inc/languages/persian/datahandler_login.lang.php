<?php
/**
 * MyBB 1.8 Persian Language Pack
 * Copyright 2014 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */

$l['logindata_invalidpwordusername'] = "شما نام‌کاربری یا رمزعبور نامعتبری را وارد کرده‌اید. <br /><br />اگر رمزعبور خود را فراموش کرده اید، لطفاً <a href=\"member.php?action=lostpw\">آن  را بازیابی کنید</a>.";
$l['logindata_invalidpwordusernameemail'] = "شما آدرس‌ایمیل یا رمزعبور نامعتبری را وارد کرده‌اید. <br /><br />اگر رمزعبور خود را فراموش کرده اید، لطفاً <a href=\"member.php?action=lostpw\">آن  را بازیابی کنید</a>.";
$l['logindata_invalidpwordusernamecombo'] = "شما نام‌کاربری/رمزعبور یا آدرس‌ایمیل/رمزعبور نامعتبری را وارد کرده‌اید. <br /><br />اگر رمزعبور خود را فراموش کرده اید، لطفاً <a href=\"member.php?action=lostpw\">آن  را بازیابی کنید</a>.";

$l['logindata_regimageinvalid'] = "کد تصویر امنیتی وارد شده صحیح نمی‌باشد، لطفا  عیناً آنچه در تصویر است را وارد کنید.";
$l['logindata_regimagerequired'] = "لطفا کدتصویر امنیتی را برای ادامه فرایند ورود در فیلد زیر وارد کنید.";