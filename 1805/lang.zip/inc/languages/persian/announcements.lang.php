<?php 
/**
 * MyBB 1.8 Persian Language Pack
 * Copyright 2014 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */

$l['nav_announcements'] = "اطلاعیه‌های انجمن";
$l['announcements'] = "اطلاعیه";
$l['forum_announcement'] = "اطلاعیه‌های انجمن: {1}";
$l['error_invalidannouncement'] = "اطلاعیه مشخص شده نامعتبر است.";
$l['announcement_edit'] = "ویرایش این اطلاعیه";
$l['announcement_qdelete'] = "حذف این اطلاعیه";
$l['announcement_quickdelete_confirm'] = "آیا شما مطمئن هستید که می‌خواهید این اطلاعیه را حذف کنید؟";