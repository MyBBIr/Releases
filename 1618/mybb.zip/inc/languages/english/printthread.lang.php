<?php 
/**
 * MyBB 1.6 English Language Pack
 * Copyright 2010 MyBB Group, All Rights Reserved
 * 
 * $Id$
 */

$l['forum'] = "Forum:";
$l['printable_version'] = "Printable Version";
$l['pages'] = "Pages:";
$l['thread'] = "Thread:";
?>