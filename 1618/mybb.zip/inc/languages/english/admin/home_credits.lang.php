<?php
/**
 * MyBB 1.6 English Language Pack
 * Copyright 2010 MyBB Group, All Rights Reserved
 * 
 * $Id$
 */

$l['mybb_credits'] = "MyBB Credits";
$l['mybb_credits_description'] = "These people have contributed their time and effort to create MyBB.";
$l['about_the_team'] = "About the Team";

$l['product_managers'] = "Product Managers";
$l['developers'] = "Developers";
$l['graphics_and_style'] = "Graphics and Style";
$l['software_quality_assurance'] = "Software Quality Assurance";
$l['support_representative'] = "Support Representative";
$l['pr_liaison'] = "PR Liaison";

?>