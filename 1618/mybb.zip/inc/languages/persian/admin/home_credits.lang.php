<?php 
/**
 * MyBB 1.6 Persian Language Pack
 * Copyright 2013 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */

$l['mybb_credits'] = "اعتبار‌های مای‌بی‌بی";
$l['mybb_credits_description'] = "این اشخاص بودند که زمان خود را برای ساخت مای‌بی‌بی گذاشتند.";
$l['about_the_team'] = "درباره‌ی گروه";
$l['product_managers'] = "گردانندگان محصول.";
$l['developers'] = "توسعه دهندگان.";
$l['graphics_and_style'] = "گرافیک و قالب";
$l['software_quality_assurance'] = "تضمین کنندگان کیفیت نرم افزار";
$l['support_representative'] = "نماینده پشتیبانی";
$l['pr_liaison'] = "روابط عمومی";
?>