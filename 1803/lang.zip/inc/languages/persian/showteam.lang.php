<?php 
/**
 * MyBB 1.8 Persian Language Pack
 * Copyright 2014 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */

$l['nav_showteam'] = "تیم مدیریتی انجمن";
$l['forum_team'] = "تیم مدیریتی انجمن";
$l['moderators'] = "مدیر‌ها";
$l['username'] = "نام‌کاربری";
$l['lastvisit'] = "آخرین بازدید";
$l['email'] = "رایانامه";
$l['pm'] = "پیام‌خصوصی";
$l['mod_forums'] = "انجمن‌(ها)";
$l['online'] = "آنلاین";
$l['offline'] = "آفلاین";
$l['group_leaders'] = "سرپرست گروه(ها)";
$l['group_members'] = "کاربر(ها)";
$l['no_members'] = "کاربری در این گروه کاربری وجود ندارد.";
$l['error_noteamstoshow'] = "تیمی‌برای نشان دادن وجود ندارد.";