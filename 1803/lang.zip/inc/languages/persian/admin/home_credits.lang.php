<?php 
/**
 * MyBB 1.8 Persian Language Pack
 * Copyright 2014 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */

$l['mybb_credits'] = "سازندگان مای‌بی‌بی";
$l['mybb_credits_description'] = "این اشخاص بودند که زمان خود را برای ساخت مای‌بی‌بی گذاشتند.";
$l['about_the_team'] = "درباره‌ی گروه";
$l['check_for_updates'] = "بررسی برای بروزرسانی";
$l['error_communication'] = "یک مشکل در دریافت نام سازندگان مای‌بی‌‌بی پیش آمده‌است، لطفا چنددقیقه‌ی دیگر تلاش کنید.";
$l['no_credits'] = "هیچ سازنده‌ای ذخیره نشده‌است. <a href=\"index.php?module=home-credits&amp;fetch_new=1\">بررسی بروزرسانی‌ها</a>.";