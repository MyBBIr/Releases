<?php 
/**
 * MyBB 1.6 Persian Language Pack
 * Copyright 2013 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */

$l['statistics'] = "آمار";
$l['overall_statistics'] = "آمار کلی";
$l['overall_statistics_desc'] = "در اینجا شما می‌توانید آمار کلی تالار خودر ا مشاهده نمایید. تمام زمان‌ها بر حسب UTC است.";
$l['date_range'] = "محدوده تاریخ";
$l['date'] = "تاریخ";
$l['users'] = "کاربران";
$l['threads'] = "موضوعات";
$l['posts'] = "ارسال‌ها";
$l['from'] = "از";
$l['to'] = "تا";
$l['increase'] = "افزایش";
$l['no_change'] = "بدون تغییر";
$l['decrease'] = "کاهش";
$l['error_no_results_found_for_criteria'] = "نتیجه‌ای برای تاریخی که مشخص کردید یافت نشد. لطفاً محدوده‌ی زمانی دیگری را انتخاب کنید.";
$l['error_no_statistics_available_yet'] = "متاسفیم، هنوز آماری برای تالار شما وجود ندارد.";
?>