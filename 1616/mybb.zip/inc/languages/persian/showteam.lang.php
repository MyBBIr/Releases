<?php 
/**
 * MyBB 1.6 Persian Language Pack
 * Copyright 2013 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */

$l['nav_showteam'] = "تیم مدیریتی انجمن";
$l['forum_team'] = "تیم مدیریتی انجمن";
$l['moderators'] = "مدیر‌ها";
$l['mod_username'] = "نام‌کاربری";
$l['mod_forums'] = "انجمن‌ها";
$l['mod_email'] = "رایانامه";
$l['mod_pm'] = "پیام‌خصوصی";
$l['uname'] = "نام‌کاربری";
$l['email'] = "رایانامه";
$l['pm'] = "پیام‌خصوصی";
$l['group_leaders'] = "سرپرست گروه(ها)";
$l['group_members'] = "کاربر(ها)";
$l['no_members'] = "کاربری در این گروه کاربری وجود ندارد.";
$l['error_noteamstoshow'] = "تیمی‌برای نشان دادن وجود ندارد.";
?>