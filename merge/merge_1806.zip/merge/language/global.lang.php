<?php
/**
 * MyBB 1.8 Merge System
 * Copyright 2014 MyBB Group, All Rights Reserved
 * Translate By: My-BB.Ir Group
 *
 * Website: http://www.mybb.com
 * License: http://www.mybb.com/download/merge-system/license/
 */

$l['next'] = "بعدی";
$l['version'] = "نسخه";
$l['none'] = "هیچ";
$l['please_wait'] = "لطفا صبر کنید...";
$l['welcome'] = "خوش آمدید";
$l['pause'] = "توقف";
$l['error'] = "خطا";
$l['warning'] = "هشدار";
$l['completed'] = "پایان یافته";
$l['dependencies'] = "وابسته";
$l['resume'] = "ازسر گرفتن";
$l['run'] = "اجرا";
$l['cleanup'] = "پاک‌سازی";
$l['yes'] = "بله";
$l['no'] = "خیر";
$l['download'] = "دریافت";
$l['redirecting'] = "درحال انتقال...";
$l['dont_wait'] = "برای دامه کلیک‌کنید، اگر که نمی‌خواهید منتظر بمانید.";
$l['back'] = "قبلی";
$l['found_error'] = "با خطایی مواجه شد";
$l['loading_data'] = "بارگذاری اطلاعات از پایگاه داده...";
$l['done'] = "انجام شد";

// Modules, english names are hardcoded. Uncomment this for your language
// Descriptions are added as "module_{key}_desc, however the current ones doesn't have a description
// Singular versions are added as "module_{key}_singular

$l['module_usergroups'] = 'گروه کاربری';
$l['module_usergroups_singular'] = 'گروه کاربری';
$l['module_users'] = 'کاربر';
$l['module_users_singular'] = 'کاربر';
$l['module_categories'] = 'دسته بندی‌ها';
$l['module_forums'] = 'انجمن';
$l['module_forums_singular'] = 'انجمن';
$l['module_forumperms'] = 'دسترسی انجمن';
$l['module_forumperms_singular'] = 'دسترسی انجمن';
// Yes, this is used twice as the key used for automatic detection is different sometimes. Will be fixed in a later release
$l['module_forum_permissions'] = 'دسترسی‌ انجمن';
$l['module_forum_permissions_singular'] = 'دسترسی انجمن';
$l['module_moderators'] = 'مدیر';
$l['module_moderators_singular'] = 'مدیر';
$l['module_threads'] = 'موضوع';
$l['module_threads_singular'] = 'موضوع';
$l['module_posts'] = 'ارسال';
$l['module_posts_singular'] = 'ارسال';
$l['module_attachments'] = 'پیوست';
$l['module_attachments_singular'] = 'پیوست';
$l['module_polls'] = 'نظرسنجی';
$l['module_polls_singular'] = 'نظرسنجی';
// Yes, this is used twice as the key used for automatic detection is different sometimes. Will be fixed in a later release
$l['module_poll_votes'] = 'نظرسنجی';
$l['module_poll_votes_singular'] = 'نظرسنجی';
$l['module_pollvotes'] = 'رای نظرسنجی';
$l['module_pollvotes_singular'] = 'رای نظرسنجی';
$l['module_privatemessages'] = 'پیام خصوصی';
$l['module_privatemessages_singular'] = 'پیام خصوصی';
// Yes, this is used twice as the key used for automatic detection is different sometimes. Will be fixed in a later release
$l['module_private_messages'] = 'پیام خصوصی';
$l['module_private_messages_singular'] = 'پیام خصوصی';
$l['module_events'] = 'رویداد';
$l['module_events_singular'] = 'رویداد';
$l['module_icons'] = 'نماد';
$l['module_icons_singular'] = 'نماد';
$l['module_smilies'] = 'شکلک';
$l['module_smilies_singular'] = 'شکلک';
$l['module_settings'] = 'تنظیم';
$l['module_settings_singular'] = 'تنظیم';
$l['module_attachtypes'] = 'نوع پیوست';
$l['module_attachtypes_singular'] = 'نوع پیوست';

$l['module_categories_singular'] = 'دسته‌بندی';

$l['creating_fields'] = "درحال ساختن فیلد‌ها برای پیگیری اطلاعات در طول فرایند ادغام (این ممکن است مدتی زبان بگیرد)...";
$l['creating_table'] = "درحال ساخت جدول {1} .";
$l['creating_columns'] = "درحال افزودن {1} ستون {2} به جدول {3}";

$l['indexpage_require'] = "سیستم ادغام مای بی‌بی به مای بی‌بی ۱.۸ برای اجرا نیاز دارد.";

$l['welcomepage_description'] = "به سیتم ادغام مای بی‌بی خوش آمدید. سیستم ادغام مای بی‌بی به منظور اجازه دادن به شما برای تبدیل یک نرم‌افزار انجمن پشتیبانی‌شده به مای بی‌بی ۱.۸ طراحی شده‌است. 
در اضافه، شما هم‌چنین می‌توانید چندین انجمن را در یک انجمن مای بی‌بی <i>ادغام</i> کنید.
<br /><br />شما می‌توانید توضیحات راهنما برای سیستم ادغام مای بی‌بی را در سایت مستندات ما مشاهده نمائید: ";
$l['welcomepage_mergesystem'] = "سیستم ادغام";
$l['welcomepage_anonymousstat'] = "ارسال آمار ادغام من به گروه مای بی‌بی";
$l['welcomepage_informations'] = "چه اطلاعاتی ارسال می‌شوند؟";
$l['welcomepage_closeboard'] = "بستن انجمن در طول ادغام";
$l['welcomepage_note'] = "سیستم ادغام مای بی‌بی برای بروزرسانی یا پیوند‌دادن انجمن‌های مای بی‌بی استفاده<u><strong>نمی‌شود</strong></u>.
در اضافه، لطفا اطمیمنان حاصل کنید همه‌ی تغییرات یا پلاگین‌ها ممکن‌است باعث  تداخل در فرایند ادغام شوند <strong>غیرفعال</strong> در هردو انجمن باشند. (انجمن قدیمی و انجمن جدید شما) ، قبل از اجرای سیستم ادغام مای بی‌بی. همچنین <strong>به شدت</strong> توصیه می‌شود تا یک بک‌آپ از هر دو انجمن خود قبل از ادامه ایجاد کنید.";
$l['welcomepage_pleasenote'] = "لطفا توجه داشته باشید";

$l['requirementspage_check'] = "بررسی نیازمندی ها";
$l['requirementspage_req'] = "نیازمندی‌ها";
$l['requirementspage_uptodate'] = "بروز";
$l['requirementspage_outofdatedesc'] = "سیستم ادغام شما تاریخ گذشته‌است! سیستم ادغام شما تا قبل از بروزرسانی آن قادر به کار نیست. آخرین نسخه: 
";
$l['requirementspage_outofdate'] = "تاریخ گذشته";
$l['requirementspage_mergeoutofdate'] = "این نسخه از سیستم ادغام تاریخ‌گذشته است.";
$l['requirementspage_unabletocheck'] = "قادر به بررسی نیست";
$l['requirementspage_unabletocheckdesc'] = "قادر به بررسی وضعیت نسخه در مقابل سرور  mybb.com نیست";
$l['requirementspage_chmoduploads'] = "پوشه‌ی پیوست‌ها (/uploads/) غیرقابل نوشتن است. لطفا دسترسی آن را بر روی ";
$l['requirementspage_chmoduploads2'] = " تنظیم کنید تا قابل نوشتن شود.";
$l['requirementspage_chmod'] = "پوشه‌ی پیوست‌ها (/uploads/) غیرقابل نوشتن است. لطفا دسترسی آنرا برروی";
$l['requirementspage_notwritable'] = "غیرقابل نوشتن";
$l['requirementspage_attnotwritable'] = "پوشه‌ی پیوست‌ها غیرقابل نوشتن‌است";
$l['requirementspage_attwritable'] = "قابل نوشتن";
$l['requirementspage_attwritabledesc'] = "پوشه‌ی پیوست‌ها قابل نوشتن است";
$l['requirementspage_reqfailed'] = "بررسی نیازمندی های سیستم ادغام با شکست مواجه شد:";
$l['requirementspage_mergeversion'] = "نسخه‌ی سیستم ادغام:";
$l['requirementspage_attwritabledesc2'] = "پوشه‌ی پیوست‌ها غیرقابل نوشتن است:";
$l['requirementspage_checkagain'] = "وقتی شما آماده بودید، بر روی \"بررسی دوباره\" برای بررسی دوباره کلیک کنید.";
$l['requirementspage_congrats'] = "تبریک می‌گوییم، شما همه‌ی نیازمندی‌ها را برای سیستم ادغام دارید! بر روی \"بعدی\" برای حرکت کلیک کنید.
";

$l['boardspage_welcome'] = "سپاس از شما برای انتخاب مای بی‌بی. این عملگر شما را به فرایند تبدیل انجمن موجود شما به مای بی‌بی هدایت می‌کند.";
$l['boardspage_boardselection'] = "انتخاب انجمن";
$l['boardspage_boardselectiondesc'] = "لطفا از لیست زیر انجمنی که می‌خواهید به مای بی‌بی تبدیل کنید را انتخاب نمائید.";

$l['module_selection'] = "انتخاب ماژول";
$l['module_selection_select'] = "لطفا یک ماژول را برای اجرا انتخاب کنید";
$l['module_selection_import'] = "واردکردن {1} ";
$l['module_selection_cleanup_desc'] = "پس از اینکه ماژولی که می‌خواهید اجرا شود را انتخاب کردید، برای فرایند تبدیل به مرحله‌ی بعد ادامه دهید.
در مرحله‌ی پاکسازی اطلاعات اضافه‌ای که در طول ادغام ساخته است را پاک می‌کند.";

$l['database_configuration'] = "پیکربندی پایگاه داده";
$l['database_settings'] = "تنظیمات پایگاه داده";
$l['database_engine'] = "موتور پایگاه داده";
$l['database_path'] = "مسیر پایگاه داده";
$l['database_host'] = "نام میزبان سرور پایگاه داده";
$l['database_user'] = "نام‌کاربری پایگاه داده";
$l['database_pw'] = "رمزعبور پایگاه داده";
$l['database_name'] = "نام پایگاه‌داده";
$l['database_table_settings'] = "تنظیمات جدول‌ها";
$l['database_table_prefix'] = "پیشوند جدول";
$l['database_table_encoding'] = "رمزگذاری جدول‌ها";
$l['database_utf8_thead'] = "رمزگذاری به UTF-8";
$l['database_utf8_desc'] = "تبدیل خودکار پیام‌ها به UTF8?:<br /><small>این را برروی خاموش قرار دهید اگر تبدیل را ساخته‌اید<br />کاراکترهای عجیب در انجمن شما.</small>";
$l['database_click_next'] = "یک بار دیگر بررسی کنید که اطلاعات درست وارد شده‌است، برای ادامه بر روی :«ادامه» کلیک کنید.";
$l['database_exit'] = "بستن پیکربندی";
$l['database_check_success'] = "بررسی اطلاعات پایگاه داده... <span style=\"color: green\">درست.</span>";
$l['database_success'] = "با موفقیت اطلاعات پایگاه داده پیکربندی شد و به پایگاه داده متصل شد.";
$l['database_details'] = "لطفا اطلاعات پایگاه داده برای نصب شما از {1} را برای انجمنی که می‌خواهید تبدیل کنید را وارد فرمائید.";

$l['wbb_installationnumber'] = "شماره نصب";
$l['wbb_installationnumber_desc'] = "چه شماره نصبی را در هنگام نصب انتخاب کرد‌اید؟";

$l['column_length_check'] = 'بررسی اینکه همه‌ی اطلاعات در جدول‌های مای بی‌بی قرار میگیرند...';
$l['column_length_checking'] = 'بررسی ستون {1} از جدول {2}';

$l['per_screen_config'] = "پیکربندی تنظیمات";
$l['per_screen'] = "لطفا انتخاب کنید که چه تعداد {1} در یک زمان وارد شود";
$l['per_screen_label'] = "{1} برای وارد در یک زمان";
$l['per_screen_autorefresh'] = "آیا شما می‌خواهید به صورت خودکار قبل از پایان ادامه دهد؟";

$l['stats_in_progress'] = "{1} {2} هم‌اکنون وارد شده است. وجود دارد {3} {2} قبل از وارد‌کردن و  {4} صفحه قبل.";
$l['stats'] = "وجود دارد {1} {2} که وارد خواهند شد.";

$l['progress'] = "درحال اضافه کردن {1} #{2}";
$l['progress_merging_user'] = "در حال ادغام #{1} با کاربر #{2}";
$l['progress_settings'] = "درحال اضافه کردن  {1} {2} از پایگاه داده دیگر شما به  {3}";
$l['progress_none_left'] = "هیچ  {1}‌ای برای واردکردن وجود ندارد. لطفا برای ادامه بر روی بعدی کلیک کنید.";
$l['progress_none_left_settings'] = "هیچ {1}‌ای برای بروزرسانی وجود ندارد. لطفا برای ادامه بر روی بعدی کلیک کنید.";

$l['import_successfully'] = "{1} با موفقیت وارد شد.";

$l['module_post_rebuilding'] = "درحال بازسازی شمارنده‌ها";
$l['module_post_rebuild_counters'] = "<br />\nدر حال بازسازی شمارنده‌های داخلی...(این ممکن است مدتی به طول انجامد)<br /><br />\n";
$l['module_post_rebuilding_thread'] = "درحال بازسازی شمارنده موضوع‌ها... ";
$l['module_post_thread_counter'] = "بازسازی شمارنده موضوع #{1}";
$l['module_post_rebuilding_forum'] = "درحال بازسازی از شمارنده‌ها...";
$l['module_post_forum_counter'] = "در حال بازسازی شمارنده‌ها بری انجمن #{1}";
$l['module_post_rebuilding_user_post'] = "درحال بازسازی شمارنده‌‌ی ارسال‌های کاربر...";
$l['module_post_user_counter'] = "درحال بازسازی شمارنده کاربر برای #{1}";
$l['module_post_rebuilding_user_thread'] = "درحال بازسازی شمارنده‌ی موضوع‌های کاربر...";

$l['module_settings_updating'] = "درحال بروزرسانی تنظیم {1}";

$l['module_attachment_link'] = "لطفا پیوند برای پوشه‌ی پیوست‌های انجمن {1} خود را وارد فرمائید";
$l['module_attachment_label'] = "پیوند به پوشه‌ی پیوست‌های شما<br /><span class='smalltext'>اگر امکان دارد از یک مسیر relative یا absolute استفاده کنید. توجه‌کنید که پوشه‌ی <b>merge</b> به عنوان مسیر کار استفاده کنید.</span>";
$l['module_attachment_error'] = "خطا در انتقال پیوست (ID: {1})";
$l['module_attachment_not_found'] = " نتوانست پیوند را پیدا کند (ID: {1})";
$l['module_attachment_create_thumbnail'] = 'ساخت خودکار بندانگشتی برای تصاویر منتقل شده';
$l['module_attachment_create_thumbnail_note'] = 'دقت کنید که بندانگشتی‌ها باید دوباره ساخته شوند اگر تنظیمات اندازه‌ی آنها تغییر کند. اگر شما هنوز ماژول تنظیمات را اجرا نکرده اید یا تصمیم دارید بعدا تنظیمات را تغییر دهید، این گزینه را بر روی خیر بگذارید.';

$l['attmodule_ipadress'] = "شما نمی‌توانید از \"localhost\" در آدرس استفاده کنید. لطفا از IP اینرنت خود استفاده نمائید(لطفا مطمئن شوید که  پورت  80 در firewall شما باز باشد).";
$l['attmodule_ipadress2'] = "شما نمی‌توانید از \"127.0.0.1\" در آدرس استفاده کنید. لطفا از IP اینرنت خود استفاده نمائید(لطفا مطمئن شوید که  پورت  80 در firewall شما باز باشد).";
$l['module_avatar_link'] = "لطفا مسیر پوشه‌ی آواتارهای {1} را وارد کنید";
$l['module_avatar_label'] = "پیوند (URL) به پوشه‌ی آواتارهای انجمنتان<br /><span class='smalltext'>اگر ممکن است از یک مسیر relative یا absolute استفاده کنید. توجه‌کنید که پوشه‌ی <b>merge</b> به عنوان مسیر کار استفاده کنید.</span>";
$l['module_avatar_error'] = "خطا در انتقال آواتار (ID: {1})";
$l['module_avatar_not_found'] = "خطا در پیدا نشدن آواتار (ID: {1})";

$l['upload_not_writeable'] = 'پوشه‌ی آپلود آواتارها ({1}) قابل نوشتن نیست. لطفا <a href="http://docs.mybb.com/CHMOD_Files.html" target="_blank">chmod</a> این پوشه را برای قابل‌نوشتن کردن‌اش تغییر دهید.';
$l['download_not_readable'] = 'پوشه قابل خواندن نیست. لطفا<a href="http://docs.mybb.com/CHMOD_Files.html" target="_blank">chmod</a> دسترسی‌ها را برای قابل خواندن کردن این پوشه تغییر دهید و مطمئن شوید که URL صحیح است. اگر شما هنوز مشکلاتی دارید، لطفا از مسیر کامل به جای URL استفاده کنید. (مثلا: /var/www/htdocs/path/to/your/old/forum/uploads/ یا C:/path/to/your/old/forum/upload/). همچنین مطمئن شوید دسترسی توسط یک فایل .htaccess بسته نشده باشد.';

$l['removing_table'] = "در حال حذف جدول {1} .";
$l['removing_columns'] = "در حال حذف ستون‌های {1} از جدول {2}";

$l['cleanup_header'] = "سیستم ادغام مای بی‌بی - مرحله‌ی پایانی: پاک سازی";
$l['cleanup_notice'] = "انجام پاک‌سازی و تعمیر و نگهداری پایانی (ممکن است مدتی زمان ببرد)...";

$l['finish_completion'] = "اتمام";
$l['finish_head'] = '<p>تبدیل سازی کنونی به اتمام رسید. شما هم‌اکنون می توانید به  <a href="../">مای بی‌بی</a> خود و یا به <a href="../{1}/index.php">کنترل پنل مدیریت</a> خود بروید.</p>
	<p>لطفا این پوشه را در صورتی که دیگر برنامه‌ای برای تبدیل‌سازی دیگر انجمن‌ها ندارید حذف کنید.</p>';
$l['finish_whats_next_head'] = "بعدی چیست؟";
$l['finish_whats_next'] = 'همانطور که انتظار می‌رود، غیرممکن است که  همه‌ی تنظیمات، شمارنده‌ها و مجوز‌ها تبدیل شوند، مطمئن شوید که همه‌چی کار می‌کند:
		<ul>
			<li>بررسی همه‌ی <a href="../{1}/index.php?module=config">تنظیمات</a></li>
			<li>بررسی دسترسی‌های <a href="../{1}/index.php?module=forum">انحمن</a> و  <a href="../{1}/index.php?module=user-groups">گروه‌ها</a></li>
		</ul>';
$l['finish_report1'] = "موارد زیر به شما اجازه می‌دهد تا گزارش مفصلی از موارد تولید شده توسط تبدیل کننده را در سبک‌های مختلف دریافت کنید.";
$l['finish_report2'] = "ساختن گزارش";
$l['finish_report_type'] = "لطفا سبک گزارش برای ساختن را انتخاب کنید.";
$l['finish_report_type_txt'] = "فایل متن ساده";
$l['finish_report_type_html'] = "فایل HTML (قابل مشاهده) File";

$l['warning_innodb'] = "جدول  \"{1}\" هم‌اکنون در فرمت InnoDB است. ما به شدت پیشنهاد می‌کنید این جدول‌ها را به فرمت MyISAM تبدیل کنید، در غیر اینصورت ممکن است سیستم ادغام آهسته‌ای را تجربه کنید.";

$l['error_no_admin'] = 'تنها مدیران کل می‌توانند سیستم ادغام را اجرا کنند، لطفا به صفحه‌ی نخست انجمن برگردید و به حساب خود وارد شوید.';

$l['error_invalid_board'] = "ماژول انجمن انتخاب شده وجود ندارد.";
$l['error_js_off'] = 'این نمایش داده می‌شود زیرا شده javascript را غیرفعال کرده‌اید. سیستم ادغام مای بی‌بی نیاز دارد تا javascript به منظور انجام درستی موارد فعال باشد. بعد از اینکه javascript را فعال کردید این صفحه را بارگذاری مجدد کنید.';
$l['error_list'] = "سیستم ادغام مای بی‌بی با مشکلات زیر مواجه شده است";
$l['error_click_next'] = "بعد از اینکه مشکلات زیر را حل کردید، شما باید برای ادامه‌ی فرایند بر روی \"بعدی\" کلیک کنید.";

$l['error_database_relative'] = "شما نمی‌توانید از URLهای نسبی برای پایگاه‌داده‌های SQLite استفاده کنید. لطفا از مسیر کامل فایل استفاده کنید (مثلا: /home/user/database.db).";
$l['error_database_invalid_engine'] = "شما یک موتور پایگاه داده نامعتبر را انتخاب کرده‌اید. لطفا انتخابتان را از لیست زیر بسازید.";
$l['error_database_cant_connect'] = "نمی‌تواند به سرور پایگاه داده در '{1}' با نام‌کاربری و رمزعبور وارد شده متصل شود. لطفا اطمینان حاصل کنید که نام هاست و اطلاعات ککاربر درست هستند؟";
$l['error_database_wrong_table'] = "پایگاه داده  {1} نمی‌تواند در  '{2}' پیدا شود.  لطفا اطمینان حاصل کنید که  {1} در این پایگاه داده با پیشوند جدول وارد شده وجود دارد.";
$l['error_database_list'] = "به نظر می‌رسد که خطایی در پیکربندی پایگاه داده شما وجود دارد";
$l['error_database_continue'] = "هنگامی که موارد بالا صحیح شد، فرایند تبدیل را ادامه دهید.";
$l['error_database_non_supported'] = 'متاسفانه به نظر می‌رسد سرور شما هیچ‌یک از موتورهای پایگاه داده مورد نیاز را پشتیبانی نمی‌کند!';
$l['error_column_length_desc'] = 'دیتابیس قدیمی شامل محتوایی است که نمیتواند به صورت خودکار ادغام شود. اطلاعات بیشتر درباره این مشکل را در <a href="http://docs.mybb.com/1.8/merge/column-length-check/">مستندات</a> بیابید.';
$l['error_column_length_table'] = 'در جدول <b>{1}</b> بخشی از محتوای ستون‌های زیر چیده خواهد شد.';
$l['error_column_length'] = '- {1} (حداکثر طول: {2})';

$l['loginconvert_title'] = "سیستم ادغام مای بی‌بی - نصب تبدیل کننده رمز عبور";
$l['loginconvert_message'] = "			<div class=\"error\">\n
				<h3>خطا</h3>
				سیستم ادغام مای بی‌بی تا قبل از آپلود loginconvert.php نمی‌تواند ادامه پیدا کند. (این در این پوشه پیدا می‌شود) که باید به پوشه‌ی  inc/plugins انتقال یابد.\n
		</div>

		<p>اطلاعات بیشتر در <a href=\"http://docs.mybb.com/1.8/merge/running/#loginconvert.php-plugin\" target=\"_blank\">اینجا</a> پیدا می‌شود.</p>
		<p>هنگامی که فایل را آپلود کردید بر روی بعدی کلیک کنید.</p>";


$l['report_txt'] = 'سیستم ادغام مای بی‌بی - گزارش ادغام
--------------------------------------------------------
به گزارش ساخته شده‌ی سیستم ادغام مای بی‌بی خوش آمدید. این
گزارش یک مرورکلی و کوچک از ادغام انجام شده را نشان می‌دهد

عمومی
-------
	انجمن ادغام شده:    {1}
	شروع وارد‌کردن:    {2}
	پایان وارد کردن: {3}

آمار کوئری‌های پایگاه داده
-------------------------
	کوئری‌ها در پایگاه داده مای بی‌بی: {4}
	کوئری‌ها در پایگاه‌داده قدیمی:  {5}
	مجموع زمان کوئری‌ها:         {6}

ماژول‌ها
-------
ماژول‌های زیر در فرایند ادغام تکمیل شدند:
{7}

آمار واردکردن
-----------------
سیستم واردکردن مای بی‌بی موارد زیر را از نسخه‌ای از {8} شما وارد کرده‌است:
{9}

خطا ها
------
این خطاها در طول فرایند سیستم ادغام رخ داده‌اند:
{10}

پرسش‌ها
---------
جدول "mybb_debuglogs" در محتویات پایگاه داده شما
اطلاعاتی درباره‌ای این ادغام به شما می‌دهد. اگر مشکلی پیدا کردید
لطفا یک پرسش در http://community.mybb.com/ ایجاد کنید.

--------------------------------------------------------
ساخته شده: {11}';

$l['report_html'] = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="rtl">
<head>
	<title>سیستم ادغام مای بی‌بی &gt; گزارش ساخته‌شده</title>
	<style type="text/css">
		body {
			font-family: Tahoma, Verdana, Arial, sans-serif;
			font-size: 12px;
			background: #efefef;
			color: #000000;
			margin: 0;
		}

		#container {
			margin: auto auto;
			width: 780px;
			background: #fff;
			border: 1px solid #ccc;
			padding: 20px;
			text-align: right;
		}

		h1 {
			font-size: 25px;
			margin: 0;
			background: #ddd;
			padding: 10px;
		}

		h2 {
			font-size: 18px;
			margin: 0;
			padding: 10px;
			background: #efefef;
		}

		h3 {
			font-size: 14px;
			clear: right;
			border-bottom: 1px dotted #aaa;
			padding-bottom: 4px;
		}

		ul, li {
			padding: 0;
		}

		#general p, #modules p, #import p, ul, li, dl {
			margin-right: 30px;
		}

		dl dt {
			float: right;
			width: 300px;
			padding-bottom: 10px;
			font-weight: bold;
		}

		dl dd {
			padding-bottom: 10px;
		}

		#footer {
			border-top: 1px dotted #aaa;
			padding-top: 10px;
			font-style: italic;
		}

		.float_left {
			float: left;
		}
	</style>
</head>
<body>
<div id="container">
	<h1>سیستم ادغام مای بی‌بی</h1>
	<h2>گزارش ادغام</h2>
	<p>به گزارش ساخته شده‌ی سیستم ادغام مای بی‌بی خوش آمدید. این گزارش یک مرورکلی و کوچک از ادغام انجام شده را نشان می‌دهد</p>
	<div id="general">
		<h3>آمار عمومی</h3>
		<p>شما {1} را به انجمن خود ادغام کرده‌اید.</p>
		<dl>
			<dt>شروع وارد کردن</dt>
			<dd>{2}</dd>

			<dt>پایان وارد کردن</dt>
			<dd>{3}</dd>
		</dl>
	</div>
	<div id="database">
		<h3>آمار کوئری‌های ادغام</h3>
		<dl>
			<dt>کوئری‌ها در پایگاه داده مای بی‌بی</dt>
			<dd>{4}</dd>

			<dt>کوئری‌ها در پایگاه داده {8}</dt>
			<dd>{5}</dd>

			<dt>مجموع زمان کوئری‌ها</dt>
			<dd>{6}</dd>
		</dl>
	</div>
	<div id="modules">
		<h3>ماژول‌ها</h3>
		<p>ماژول‌های زیر در فرایند ادغام تکمیل شدند:</p>
		<ul>
		{7}
		</ul>
	</div>
	<div id="import">
		<h3>آمار واردکردن</h3>
		<p>سیستم واردکردن مای بی‌بی موارد زیر را از نسخه‌ای از {8} شما وارد کرده‌است:</p>
		<dl>
		{9}
		</dl>
	</div>
	<div id="errors">
		<h3>خطا ها</h3>
		<p>این خطاها در طول فرایند سیستم ادغام رخ داده‌اند:</p>
		<ul>
		{10}
		</ul>
	</div>
	<div id="problems">
		<h3>پرسش‌ها؟</h3>
		<p>جدول "mybb_debuglogs" در محتویات پایگاه داده شما
اطلاعاتی درباره‌ای این ادغام به شما می‌دهد. اگر مشکلی پیدا کردید
لطفا یک پرسش در  <a href="http://community.mybb.com/">MyBB Community Forums</a> ایجاد کنید.</p>
	</div>
	<div id="footer">
		<div class="float_left">MyBB &copy; 2002-{12} MyBB Group - <a href="http://my-bb.ir" target="_blank">گروه مای بی‌بی فارسی</a></div>
		<div>ساخته شده در: {11}</div>
	</div>
</div>
</body>
</html>';