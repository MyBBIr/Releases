<?php 
/**
 * MyBB 1.6 Persian Language Pack
 * Copyright 2013 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */
 
$l['error_no_connection'] = "خطای در برقراری ارتباط از طریق سرور وجود دارد:";
$l['error_no_message'] = "هیچ پیام مشخص شده‌ای وجود ندارد.";
$l['error_no_subject'] = "هیچ موضوع مشخص شده‌ای وجود ندارد.";
$l['error_no_recipient'] = "هیچ گیرنده‌ی مشخص شده‌ای وجود ندارد.";
$l['error_not_sent'] = "یک خطا در ارسال پیام در تابع mail در پی‌اچ‌پی وجود دارد.";
$l['error_status_missmatch'] = "نتیجه آمار از عدم تطابق سرور انتظار می‌رود، در حال بازگشت";
$l['error_data_not_sent'] = "این اطلاعات نمی‌تواند به سرور ارسال شود:";
$l['error_occurred'] = "یک یا چند خطا وجود دارد، لطفا قبل از ادامه این خطا‌ها را حل کنید.<br />";
?>