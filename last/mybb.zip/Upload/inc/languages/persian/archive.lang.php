<?php 
/**
 * MyBB 1.8 Persian Language Pack
 * Copyright 2014 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */

$l['archive_fullversion'] = "نسخه‌ی کامل:";
$l['archive_replies'] = "پاسخ‌ها:";
$l['archive_reply'] = "پاسخ:";
$l['archive_pages'] = "صفحات:";
$l['archive_note'] = "شما در حال مشاهده نسخه آرشیو هستید. برای <a href=\"{1}\">مشاهده نسخه کامل</a> کلیک کنید.";
$l['archive_nopermission'] = "با عرض پوزش، شما اجازه دسترسی به این بخش را ندارید.";
$l['error_nothreads'] = "موضوعی در این انجمن یافت نشد";
$l['error_unapproved_thread'] = "این موضوع تایید نشده است.لطفا برای مشاهده محتویات موضوع <a href=\"{1}\">نسخه کامل انجمن</a> را مشاهده کنید.";
$l['archive_not_found'] = "صفحه درخواست شده یافت نشد.";
$l['error_mustlogin'] = "این انجمن همه‌ی کاربران را به ورود وادار کرده‌است.";