<?php 
/**
 * MyBB 1.6 Persian Language Pack
 * Copyright 2013 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */

/*
 * Custom Help Document Translation Format
 *
 * // Help Document {hid}
 * $l['d{hid}_name'] = "Document name";
 * $l['d{hid}_desc'] = "Document description";
 * $l['d{hid}_document'] = "Document text";
 */
?>