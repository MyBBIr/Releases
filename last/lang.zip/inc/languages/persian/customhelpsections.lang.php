<?php 
/**
 * MyBB 1.6 Persian Language Pack
 * Copyright 2013 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */

/*
 * Custom Help Section Translation Format
 *
 * // Help Section {sid}
 * $l['s{sid}_name'] = "Section name";
 * $l['s{sid}_desc'] = "Section description";
 */
?>