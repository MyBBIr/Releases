<?php 
/**
 * MyBB 1.6 English Language Pack
 * Copyright 2012 MyBB Group, All Rights Reserved
 * 
 * $Id: report.lang.php 5297 2012-12-28 22:01:14Z Tomm $
 */

$l['report_post'] = "گزارش ارسال";
$l['report_to_mod'] = "گزارش این ارسال به ناظم";
$l['only_report'] = "باید تنها هرزنامه، تبلیغات و سوء استفاده را گزارش دهید.";
$l['report_reason'] = "دلیل شما برای گزارش این ارسال:";
$l['thank_you'] = "متشکریم.";
$l['post_reported'] = "ارسال با موفقیت گزارش داده شد. شما اکنون می‌توانید این پنجره را ببندید.";
$l['report_error'] = "خطا";
$l['no_reason'] = "شما نمی‌توانید یک ارسال را بدون درج دلایل خود گزارش دهید.";
$l['go_back'] = "بازگشت";
$l['close_window'] = "بستن پنجره";
?>