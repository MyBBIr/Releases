<?php 
/**
 * MyBB 1.6 English Language Pack
 * Copyright 2010 MyBB Group, All Rights Reserved
 * 
 * $Id: printthread.lang.php 5297 2010-12-28 22:01:14Z Tomm $
 */

$l['forum'] = "Forum:";
$l['printable_version'] = "Printable Version";
$l['pages'] = "Pages:";
$l['thread'] = "Thread:";
?>