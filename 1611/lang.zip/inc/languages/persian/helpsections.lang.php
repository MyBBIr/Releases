<?php
/**
 * MyBB 1.6 Persian Language Pack
 * Copyright 2013 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */
/* Uncomment the lines below to use these language strings rather than the help documents set in the database */

/* 
// Help Section 1
$l['s1_name'] = "تعمیر و نگهداری کاربر";
$l['s1_desc'] = "دستورالعمل کاری برای نگهداری حساب کاربری در انجمن.";
// Help Section 2
$l['s2_name'] = "در حال ارسال";
$l['s2_desc'] = "در حال ارسال یا پاسخ دادن به موضوع و استفاده معمولی از انجمن";
*/
?>