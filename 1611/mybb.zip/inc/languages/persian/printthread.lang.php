<?php 
/**
 * MyBB 1.6 Persian Language Pack
 * Copyright 2013 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */

$l['forum'] = "انجمن:";
$l['printable_version'] = "نسخه قابل چاپ";
$l['pages'] = "صفحات";
$l['thread'] = "موضوع:";
?>