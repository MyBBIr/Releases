<?php
/**
 * MyBB 1.6 Persian Language Pack
 * Copyright 2013 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */
 
$l['home'] = "صفحه اصلی";
$l['dashboard'] = "میزِکار";
$l['preferences'] = "تنظیم‌های شخصی";
$l['version_check'] = "بررسی نسخه";
$l['mybb_credits'] = "اعتبار مای‌بی‌بی";
$l['add_new_forum'] = "افزودن انجمن جدید";
$l['search_for_users'] = "جستجوی کاربر";
$l['themes'] = "پوسته‌ها";
$l['templates'] = "قالب‌ها";
$l['plugins'] = "افزونه‌ها";
$l['database_backups'] = "فایل‌های پشتیبان";
$l['quick_access'] = "دستیابی سریع";
$l['online_admins'] = "مدیران آنلاین";
?>