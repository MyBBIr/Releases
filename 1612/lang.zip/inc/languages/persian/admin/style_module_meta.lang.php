<?php 
/**
 * MyBB 1.6 Persian Language Pack
 * Copyright 2013 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */
 
$l['templates_and_style'] = "قالب‌ها و پوسته‌ها";
$l['themes'] = "پوسته‌ها";
$l['templates'] = "قالب‌ها";
$l['can_manage_themes'] = "می‌توان پوسته‌ها را مدیریت کرد؟";
$l['can_manage_templates'] = "می‌توان قالب‌ها را ویرایش کرد؟";
?>