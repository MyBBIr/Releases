<?php 
/**
 * MyBB 1.6 Persian Language Pack
 * Copyright 2013 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */

$l['all_forums'] = "همه‌ی انجمن‌ها";
$l['forum'] = "انجمن:";
$l['posted_by'] = "ارسال‌شده‌توسط:";
$l['on'] = "در";
?>