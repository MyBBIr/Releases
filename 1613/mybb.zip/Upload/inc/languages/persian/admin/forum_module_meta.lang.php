<?php 
/**
 * MyBB 1.6 Persian Language Pack
 * Copyright 2013 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */
 
$l['forums_and_posts'] = "انجمن‌ها و ارسال‌ها";
$l['forum_management'] = "مدیریت انجمن";
$l['forum_announcements'] = "اعلانات انجمن";
$l['moderation_queue'] = "صف مدیریت";
$l['attachments'] = "پیوست‌ها";
$l['can_manage_forums'] = "بتواند انجمن‌ها را مدیریت نماید؟";
$l['can_manage_forum_announcements'] = "بتواند اعلانات انجمن را مدیریت نماید؟";
$l['can_moderate'] = "بتواندارسال‌ها، موضوعات و پیوست‌ها را مدیریت نماید؟";
$l['can_manage_attachments'] = "بتواند پیوست‌ها را مدیریت نماید؟";
?>